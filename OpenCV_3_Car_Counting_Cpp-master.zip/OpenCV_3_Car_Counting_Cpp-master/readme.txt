The video pretty much explains it all:
https://www.youtube.com/watch?v=Y3ac5rFMNZ0